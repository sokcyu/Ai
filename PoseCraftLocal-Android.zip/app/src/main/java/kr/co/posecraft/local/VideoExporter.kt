package kr.co.posecraft.local

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File

object VideoExporter {
    fun kenBurns(source: Bitmap, output: File, seconds: Int = 4, fps: Int = 24) {
        val width = 720
        val height = 720
        val format = MediaFormat.createVideoFormat("video/avc", width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = codec.createInputSurface()
        codec.start()
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val info = MediaCodec.BufferInfo()
        var track = -1
        var muxerStarted = false
        val total = seconds * fps
        repeat(total) { frame ->
            val canvas = surface.lockCanvas(null)
            drawFrame(canvas, source, frame.toFloat() / (total - 1).coerceAtLeast(1))
            surface.unlockCanvasAndPost(canvas)
            drain(codec, muxer, info, false, { index -> track = index; muxerStarted = true }, { track })
        }
        codec.signalEndOfInputStream()
        while (!drain(codec, muxer, info, true, { index -> track = index; muxerStarted = true }, { track })) Unit
        codec.stop(); codec.release(); surface.release()
        if (muxerStarted) muxer.stop()
        muxer.release()
    }

    private fun drawFrame(canvas: Canvas, bitmap: Bitmap, progress: Float) {
        canvas.drawColor(Color.BLACK)
        val base = maxOf(canvas.width.toFloat() / bitmap.width, canvas.height.toFloat() / bitmap.height)
        val scale = base * (1f + .12f * progress)
        val left = (canvas.width - bitmap.width * scale) / 2f - 18f * progress
        val top = (canvas.height - bitmap.height * scale) / 2f - 12f * progress
        canvas.save(); canvas.translate(left, top); canvas.scale(scale, scale)
        canvas.drawBitmap(bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        canvas.restore()
    }

    private fun drain(codec: MediaCodec, muxer: MediaMuxer, info: MediaCodec.BufferInfo,
                      eos: Boolean, onFormat: (Int) -> Unit, currentTrack: () -> Int): Boolean {
        var ended = false
        while (true) {
            val index = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val track = muxer.addTrack(codec.outputFormat); muxer.start(); onFormat(track)
                }
                index >= 0 -> {
                    codec.getOutputBuffer(index)?.let { buffer ->
                        if (info.size > 0) {
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            muxer.writeSampleData(currentTrack(), buffer, info)
                        }
                    }
                    ended = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(index, false)
                }
            }
        }
        return ended
    }
}
