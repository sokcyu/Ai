package kr.co.posecraft.local

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var preview: ImageView
    private lateinit var prompt: EditText
    private lateinit var status: TextView
    private lateinit var busy: ProgressBar
    private var bitmap: Bitmap? = null
    private var rotation = 0f
    private var saturation = 1f
    private val modelDir by lazy { File(filesDir, "image_generator/bins") }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.openInputStream(uri)?.use { bitmap = BitmapFactory.decodeStream(it) }
        renderEdited()
    }
    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runBusy("모델을 복사하는 중…") { copyTree(uri, modelDir) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        status.text = if (modelDir.exists() && modelDir.list()?.isNotEmpty() == true)
            "로컬 모델 준비됨 · 인터넷 없이 생성 가능" else "먼저 ‘AI 모델 선택’을 눌러 모델 폴더를 지정하세요."
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16)); setBackgroundColor(0xff0e0b16.toInt())
        }
        root.addView(TextView(this).apply {
            text = "PoseCraft Local"; textSize = 27f; setTextColor(0xffffffff.toInt())
        })
        root.addView(TextView(this).apply {
            text = "무료 · 로그인 없음 · 생성 횟수 제한 없음"; setTextColor(0xffb7a8ff.toInt())
        })
        status = TextView(this).apply { setTextColor(0xffdddddd.toInt()); setPadding(0, dp(12), 0, dp(8)) }
        root.addView(status)
        preview = ImageView(this).apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xff201a2d.toInt())
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        prompt = EditText(this).apply {
            hint = "만들 이미지 설명 (예: 네온 콘서트의 DJ)"; setTextColor(0xffffffff.toInt()); setHintTextColor(0xff888888.toInt())
            setSingleLine(false); minLines = 2
        }
        root.addView(prompt)
        root.addView(row(
            button("AI 모델 선택") { pickModel.launch(null) },
            button("문장으로 생성") { generate() },
            button("사진 불러오기") { pickImage.launch("image/*") }
        ))
        root.addView(labeledSlider("자세/구도 회전", -25, 25, 0) { rotation = it.toFloat(); renderEdited() })
        root.addView(labeledSlider("색감", 0, 200, 100) { saturation = it / 100f; renderEdited() })
        root.addView(row(
            button("이미지 저장") { saveImage() },
            button("4초 영상 만들기") { exportVideo() },
            button("초기화") { rotation = 0f; saturation = 1f; renderEdited() }
        ))
        busy = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(busy, LinearLayout.LayoutParams(-1, dp(5)))
        return root
    }

    private fun generate() {
        val text = prompt.text.toString().trim()
        if (text.isEmpty()) return toast("이미지 설명을 입력하세요.")
        if (!modelDir.exists() || modelDir.list().isNullOrEmpty()) return toast("AI 모델 폴더를 먼저 선택하세요.")
        runBusy("휴대폰에서 이미지를 생성하는 중…") {
            LocalImageEngine(this, modelDir).use { bitmap = it.generate(text) }
        }
    }

    private fun renderEdited() {
        val source = bitmap ?: return
        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(saturation) })
        }
        canvas.rotate(rotation, source.width / 2f, source.height / 2f)
        canvas.drawBitmap(source, 0f, 0f, paint)
        preview.setImageBitmap(out)
    }

    private fun editedBitmap(): Bitmap? {
        preview.drawable ?: return null
        val source = bitmap ?: return null
        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(saturation) })
        }
        c.rotate(rotation, source.width / 2f, source.height / 2f); c.drawBitmap(source, 0f, 0f, p)
        return out
    }

    private fun saveImage() {
        val image = editedBitmap() ?: return toast("먼저 이미지를 만들거나 불러오세요.")
        val name = "PoseCraft_${System.currentTimeMillis()}.png"
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        }) ?: return toast("저장 공간을 열 수 없습니다.")
        contentResolver.openOutputStream(uri)?.use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
        toast("갤러리에 저장했습니다.")
    }

    private fun exportVideo() {
        val image = editedBitmap() ?: return toast("먼저 이미지를 만들거나 불러오세요.")
        runBusy("4초 영상을 만드는 중…") {
            val file = File(cacheDir, "PoseCraft_${System.currentTimeMillis()}.mp4")
            VideoExporter.kenBurns(image, file)
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            }) ?: error("동영상 저장소를 열 수 없습니다.")
            contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
        }
    }

    private fun copyTree(uri: Uri, destination: File) {
        destination.mkdirs()
        val root = DocumentFile.fromTreeUri(this, uri) ?: error("모델 폴더를 열 수 없습니다.")
        fun copy(node: DocumentFile, target: File) {
            if (node.isDirectory) {
                target.mkdirs(); node.listFiles().forEach { copy(it, File(target, it.name ?: "file")) }
            } else contentResolver.openInputStream(node.uri)!!.use { input -> target.outputStream().use { input.copyTo(it) } }
        }
        root.listFiles().forEach { copy(it, File(destination, it.name ?: "file")) }
    }

    private fun runBusy(message: String, job: () -> Unit) {
        busy.visibility = View.VISIBLE; status.text = message
        worker.execute {
            val result = runCatching(job)
            runOnUiThread {
                busy.visibility = View.GONE
                status.text = result.fold({ "완료했습니다." }, { "오류: ${it.message}" })
                if (result.isSuccess) renderEdited()
            }
        }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        views.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
    }
    private fun labeledSlider(label: String, min: Int, max: Int, value: Int, changed: (Int) -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(TextView(context).apply { text = label; setTextColor(0xffdddddd.toInt()) }, LinearLayout.LayoutParams(0, -2, .35f))
            addView(SeekBar(context).apply {
                this.min = min; this.max = max; progress = value
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) changed(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) = Unit
                    override fun onStopTrackingTouch(s: SeekBar?) = Unit
                })
            }, LinearLayout.LayoutParams(0, -2, .65f))
        }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}
