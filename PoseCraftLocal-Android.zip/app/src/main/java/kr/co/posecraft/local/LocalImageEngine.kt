package kr.co.posecraft.local

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapExtractor
import com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator
import com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator.ImageGeneratorOptions
import java.io.Closeable
import java.io.File

/** Runs Stable Diffusion locally. No account, credits, or network call is used. */
class LocalImageEngine(context: Context, modelDirectory: File) : Closeable {
    private val generator = ImageGenerator.createFromOptions(
        context,
        ImageGeneratorOptions.builder()
            .setImageGeneratorModelDirectory(modelDirectory.absolutePath)
            .build()
    )

    fun generate(prompt: String, steps: Int = 20, seed: Int = (0..Int.MAX_VALUE).random()): Bitmap {
        val result = generator.generate(prompt, steps, seed)
        return BitmapExtractor.extract(result.generatedImage())
    }

    override fun close() = generator.close()
}
